import { StyleSheet } from "react-native";
import { Fonts, Metrics, Colors } from "../../Themes";
const styles = StyleSheet.create({
  customStyles: {
    color: Colors.ember
  }
});

export default styles;
